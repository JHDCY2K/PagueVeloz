﻿using System.Linq;
using PV.Dominio.Entidades;
using PV.Dominio.Repositorios;

namespace PV.Dados.Repositorios
{
    public class RepositorioFornecedor : Repositorio<Fornecedor>, IRepositorioFornecedor
    {

        public RepositorioFornecedor(ContextoExemploPV ContextoExemploPV) : base(ContextoExemploPV)
        {
        }

        public Fornecedor ObterPorNome(string nome)
        {
            return Contexto.Set<Fornecedor>()
                        .Where(p => p.Nome == nome)
                        .SingleOrDefault();
                        
        }

    }
}
