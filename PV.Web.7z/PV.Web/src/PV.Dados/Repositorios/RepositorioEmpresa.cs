﻿using System.Linq;
using PV.Dominio.Entidades;
using PV.Dominio.Repositorios;

namespace PV.Dados.Repositorios
{
    public class RepositorioEmpresa : Repositorio<Empresa>, IRepositorioEmpresa
    {

        public RepositorioEmpresa(ContextoExemploPV ContextoExemploPV) : base(ContextoExemploPV)
        {
        }

        public Empresa ObterPorNome(string nome)
        {
            return Contexto.Set<Empresa>()
                        .Where(p => p.Nome == nome )
                        .SingleOrDefault();
                        
        }

    }
}
