﻿using System;
using System.Linq;
using PV.Dominio.Entidades;
using PV.Dominio.Repositorios;

namespace PV.Dados.Repositorios
{
    public class Repositorio<T> : IRepositorio<T> where T : Entidade, new()
    {
        protected readonly ContextoExemploPV Contexto;

        public Repositorio(ContextoExemploPV contexto)
        {
            if (contexto == null)
                throw new ArgumentNullException(nameof(contexto));

            Contexto = contexto;
        }

        public void Alterar(T entidade)
        {
            Contexto.Set<T>().Update(entidade);
        }

        public void Excluir(long id)
        {
            Contexto.Set<T>().Remove(ObterPorId(id));
        }

        public void Incluir(T entidade)
        {
            Contexto.Set<T>().Add(entidade);
        }

        public T ObterPorId(long id)
        {
            return Contexto.Set<T>().Find(id);
        }

        public IQueryable<T> ObterTodos()
        {
            return Contexto.Set<T>();
        }
    }
}
