﻿using System.Linq;
using PV.Dominio.Entidades;
using PV.Dominio.Repositorios;

namespace PV.Dados.Repositorios
{
    public class RepositorioUsuario : Repositorio<Usuario>, IRepositorioUsuario
    {

        public RepositorioUsuario(ContextoExemploPV ContextoExemploPV) : base(ContextoExemploPV)
        {
        }

        public Usuario ObterPorLogin(string login)
        {
            return Contexto.Set<Usuario>()
                        .Where(p => p.Login == login )
                        .SingleOrDefault();
                        
        }

    }
}
