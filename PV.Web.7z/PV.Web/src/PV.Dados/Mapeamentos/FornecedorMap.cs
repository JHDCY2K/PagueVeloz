﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PV.Dominio.Entidades;

namespace PV.Dados
{
    public class FornecedorMap : IEntityTypeConfiguration<Fornecedor>
    {
        public void Configure(EntityTypeBuilder<Fornecedor> builder)
        {
            builder.Property(c => c.Id)
                .HasColumnType("long")
                .IsRequired();
            builder.Property(c => c.idEmpresa)
                .HasColumnType("long")
                .IsRequired();

            builder.Property(c => c.Nome)
                .HasColumnType("varchar(100)")
                .HasMaxLength(100)
                .IsRequired();

            builder.Property(c => c.CNPJCPF)
                .HasColumnType("varchar(14)")
                .HasMaxLength(14)
                .IsRequired();

            builder.Property(c => c.Telefone)
               .HasColumnType("varchar(15)")
               .HasMaxLength(15)
               .IsRequired();

            builder.Property(c => c.TipoFornecedor)
               .HasColumnType("varchar(2)")
               .HasMaxLength(2)
               .IsRequired();

            builder.Property(c => c.Rg)
              .HasColumnType("varchar(15)")
              .HasMaxLength(15)
              .IsRequired();

            builder.Property(c => c.DataNascimento)
              .HasColumnType("date")
              .IsRequired();

        }
    }
}
