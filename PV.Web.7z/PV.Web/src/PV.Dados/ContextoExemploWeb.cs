﻿using System;
using Microsoft.EntityFrameworkCore;
using PV.Dominio.Entidades;

namespace PV.Dados
{
    public class ContextoExemploPV : DbContext
    {
        private readonly string _stringConexao;

		private DbContextOptions<ContextoExemploPV> options;

        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Empresa> Empresa { get; set; }
        public DbSet<Fornecedor> Fornecedor { get; set; }

        public ContextoExemploPV(string stringConexao)
        {
            if (string.IsNullOrWhiteSpace(stringConexao))
                throw new ArgumentNullException(nameof(stringConexao));

            _stringConexao = stringConexao;
        }

		public ContextoExemploPV(DbContextOptions<ContextoExemploPV> options)
        {
            this.options = options;
        }

		protected override void OnModelCreating(ModelBuilder builder)
        {
            #region ExemploWeb-metadado
            #endregion

            base.OnModelCreating(builder);
        }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_stringConexao);
        }
    }
}