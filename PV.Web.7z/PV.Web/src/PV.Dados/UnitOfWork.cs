﻿using System;
using PV.Dominio.Repositorios;

namespace PV.Dados
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ContextoExemploPV _contexto;

        public UnitOfWork(ContextoExemploPV contexto)
        {
            if (contexto == null)
                throw new ArgumentNullException(nameof(contexto));

            _contexto = contexto;
        }

        public void SaveChanges()
        {
            _contexto.SaveChanges();
        }
    }
}