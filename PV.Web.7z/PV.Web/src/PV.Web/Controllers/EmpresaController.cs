﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Omu.ValueInjecter;
using PV.Dominio.Entidades;
using PV.Dominio;
using PV.Dtos;
using PV.Dominio.Repositorios;

namespace PV.Web.Controllers
{
    [Authorize]
    public class EmpresaController : Controller
    {

        private readonly IServicoEmpresa servicoEmpresa;
        private readonly IUnitOfWork unitOfWork;

        public EmpresaController(IServicoEmpresa servicoEmpresa, IUnitOfWork unitOfWork)
        {
            this.servicoEmpresa = servicoEmpresa ?? throw new ArgumentNullException(nameof(servicoEmpresa));
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }

        // GET: Empresas
        public IActionResult Index()
        {
            var empresas = servicoEmpresa.ObterEmpresas();
            List<EmpresaModel> empresasModel = TransformarEmpresasEmModel(empresas);
            return View(empresasModel);
        }

        private static List<EmpresaModel> TransformarEmpresasEmModel(IEnumerable<Empresa> empresas)
        {
            List<EmpresaModel> empresasModel = new List<EmpresaModel>();
            foreach (var empresa in empresas)
            {
                EmpresaModel empresaModel = TransformarEmpresaEmModel(empresa);
                empresasModel.Add(empresaModel);
            }

            return empresasModel;
        }

        private static EmpresaModel TransformarEmpresaEmModel(Empresa empresa)
        {
            EmpresaModel empresaModel = new EmpresaModel();
            empresaModel.InjectFrom(empresa);
            return empresaModel;
        }

        // GET: Empresas/Details/5
        public IActionResult Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var empresa = servicoEmpresa.ObterPorId(id.Value);
            if (empresa == null)
            {
                return NotFound();
            }
            EmpresaModel empresaModel = TransformarEmpresaEmModel(empresa);

            return View(empresaModel);
        }

        // GET: Empresas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Empresas/Create        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,Nome,UF,CNPJ")] EmpresaModel empresaModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Empresa empresa = new Empresa();
                    empresa.InjectFrom(empresaModel);
                    servicoEmpresa.Inserir(empresa, User.Identity.Name);
                    unitOfWork.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(empresaModel);
        }

        // GET: Empresas/Edit/5
        public IActionResult Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var empresa = servicoEmpresa.ObterPorId(id.Value);
            if (empresa == null)
            {
                return NotFound();
            }
            EmpresaModel empresaModel = TransformarEmpresaEmModel(empresa);
            return View(empresaModel);
        }

        // POST: Empresas/Edit/5        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("Nome,UF,CNPJ")] EmpresaModel empresaModel)
        {
            if (id != empresaModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    Empresa empresa = servicoEmpresa.ObterPorId(empresaModel.Id);
                    empresa.InjectFrom(empresaModel);

                    servicoEmpresa.Atualizar(empresa, User.Identity.Name);
                    unitOfWork.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(empresaModel);
        }

        // GET: Empresas/Delete/5
        public IActionResult Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var empresa = servicoEmpresa.ObterPorId(id.Value);
            if (empresa == null)
            {
                return NotFound();
            }
            EmpresaModel empresaModel = TransformarEmpresaEmModel(empresa);

            return View(empresaModel);
        }

        // POST: Empresas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(long id)
        {
            var empresa = servicoEmpresa.ObterPorId(id);
            servicoEmpresa.Remover(empresa);
            unitOfWork.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}
