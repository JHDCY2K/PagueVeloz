﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Omu.ValueInjecter;
using PV.Dominio.Entidades;
using PV.Dominio;
using PV.Dtos;
using PV.Dominio.Repositorios;

namespace PV.Web.Controllers
{
    [Authorize]
    public class FornecedorController : Controller
    {

        private readonly IServicoFornecedor servicoFornecedor;
        private readonly IUnitOfWork unitOfWork;

        public FornecedorController(IServicoFornecedor servicoFornecedor, IUnitOfWork unitOfWork)
        {
            this.servicoFornecedor = servicoFornecedor ?? throw new ArgumentNullException(nameof(servicoFornecedor));
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }

        // GET: Fornecedores
        public IActionResult Index()
        {
            var fornecedores = servicoFornecedor.ObterFornecedores();
            List<FornecedorModel> fornecedorModel = TransformarFornecedoresEmModel(fornecedores);
            return View(fornecedorModel);
        }
        
        [HttpGet]
        public IActionResult Filtrar()
        {
            var fornecedores = servicoFornecedor.ObterFornecedores();
            List<FornecedorModel> fornecedorModel = TransformarFornecedoresEmModel(fornecedores);
            return View(fornecedorModel);
        }

        private static List<FornecedorModel> TransformarFornecedoresEmModel(IEnumerable<Fornecedor> fornecedores)
        {
            List<FornecedorModel> fornecedorModel = new List<FornecedorModel>();
            foreach (var fornecedor in fornecedores)
            {
                FornecedorModel empresaModel = TransformarFornecedorEmModel(fornecedor);
                fornecedorModel.Add(empresaModel);
            }

            return fornecedorModel;
        }

        private static FornecedorModel TransformarFornecedorEmModel(Fornecedor fornecedor)
        {
            FornecedorModel empresaModel = new FornecedorModel();
            empresaModel.InjectFrom(fornecedor);
            return empresaModel;
        }

        // GET: Fornecedores/Details/5
        public IActionResult Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fornecedor = servicoFornecedor.ObterPorId(id.Value);
            if (fornecedor == null)
            {
                return NotFound();
            }
            FornecedorModel empresaModel = TransformarFornecedorEmModel(fornecedor);

            return View(empresaModel);
        }

        // GET: Fornecedores/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Fornecedores/Create        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,Nome,idEmpresa,CNPJCPF,Telefone,TipoFornecedor,Rg,DataNascimento")] FornecedorModel empresaModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Fornecedor fornecedor = new Fornecedor();
                    fornecedor.InjectFrom(empresaModel);
                    servicoFornecedor.Inserir(fornecedor, User.Identity.Name);
                    unitOfWork.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(empresaModel);
        }

        // GET: Fornecedores/Edit/5
        public IActionResult Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fornecedor = servicoFornecedor.ObterPorId(id.Value);
            if (fornecedor == null)
            {
                return NotFound();
            }
            FornecedorModel empresaModel = TransformarFornecedorEmModel(fornecedor);
            return View(empresaModel);
        }

        // POST: Fornecedores/Edit/5        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("Nome,idEmpresa,CNPJCPF,Telefone,TipoFornecedor,Rg,DataNascimento")] FornecedorModel empresaModel)
        {
            if (id != empresaModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    Fornecedor fornecedor = servicoFornecedor.ObterPorId(empresaModel.Id);
                    fornecedor.InjectFrom(empresaModel);

                    servicoFornecedor.Atualizar(fornecedor, User.Identity.Name);
                    unitOfWork.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(empresaModel);
        }

        // GET: Fornecedores/Delete/5
        public IActionResult Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fornecedor = servicoFornecedor.ObterPorId(id.Value);
            if (fornecedor == null)
            {
                return NotFound();
            }
            FornecedorModel empresaModel = TransformarFornecedorEmModel(fornecedor);

            return View(empresaModel);
        }

        // POST: Fornecedores/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(long id)
        {
            var fornecedor = servicoFornecedor.ObterPorId(id);
            servicoFornecedor.Remover(fornecedor);
            unitOfWork.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}
