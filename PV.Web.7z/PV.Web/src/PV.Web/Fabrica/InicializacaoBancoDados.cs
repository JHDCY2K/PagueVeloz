﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PV.Dados;
using PV.Dominio.Entidades;
using PV.Dominio.Servicos;

namespace PV.Web
{
    public static class InicializacaoBancoDados
    {
        public static void Inicializar(IServiceProvider serviceProvider)
        {
            ContextoExemploPV contextoPV = serviceProvider.GetService(typeof(ContextoExemploPV)) as ContextoExemploPV;
            IServicoCriptografia servicoCriptografia = serviceProvider.GetService(typeof(IServicoCriptografia)) as IServicoCriptografia;

            if (contextoPV.Usuario.Any())
            {
                return;
            }

            var usuario = new Usuario()
            {
                Nome = "Administrator",
                Senha = servicoCriptografia.Gerar("123"),
                Login = "admin",
                Ativo = true,
                DataCriacao = DateTime.Now,
                CriadoPor = "Sistema",
                DataAlteracao = (DateTime?)null,
                AlteradoPor = null,
                UltimoLogin = (DateTime?)null
            };

            contextoPV.Usuario.Add(usuario);

            contextoPV.SaveChanges();

        }
    }
}
