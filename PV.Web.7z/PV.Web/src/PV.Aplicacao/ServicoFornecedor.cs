﻿using System;
using System.Collections.Generic;
using PV.Dominio;
using PV.Dominio.Entidades;
using PV.Dominio.Repositorios;
using PV.Dominio.Servicos;

namespace PV.Aplicacao
{
    public class ServicoFornecedor : IServicoFornecedor
    {
        private readonly IRepositorioFornecedor repositorioFornecedor;
        private readonly IRepositorioEmpresa repositorioEmpresa;

        public ServicoFornecedor(IRepositorioFornecedor repositorioFornecedor, IRepositorioEmpresa repositorioEmpresa)
        {
            this.repositorioFornecedor = repositorioFornecedor ?? throw new ArgumentNullException(nameof(repositorioFornecedor));
            this.repositorioEmpresa = repositorioEmpresa ?? throw new ArgumentNullException(nameof(repositorioEmpresa));
        }

        public void Atualizar(Fornecedor fornecedor, string alteradoPor)
        {
            ValidarFornecedor(fornecedor);

            fornecedor.DataAlteracao = DateTime.Now;
            fornecedor.AlteradoPor = alteradoPor;

            repositorioFornecedor.Alterar(fornecedor);
        }

        private void ValidarFornecedor(Fornecedor fornecedor)
        {
            if (fornecedor == null)
                throw new NullReferenceException(nameof(fornecedor));
            if (fornecedor.Nome == null)
                throw new Exception("Nome inválido");
            if (fornecedor.idEmpresa == 0)
                throw new Exception("Empresa inválida, consulte o código da empresa no cadastro de Empresa");

            // valida se a empresa esta cadastrada
            var empresa = repositorioEmpresa.ObterPorId(fornecedor.idEmpresa);

            if (empresa == null)
                throw new Exception("Empresa inválida, consulte o código da empresa no cadastro de Empresa");

            // se tipo fornecedor = PF
            if (fornecedor.TipoFornecedor == null)
                throw new Exception("Tipo Fornecedor deve ser PJ ou PF");
            if (fornecedor.TipoFornecedor != "PJ" && fornecedor.TipoFornecedor != "PF")
                throw new Exception("Tipo Fornecedor deve ser PJ ou PF");

            if (fornecedor.TipoFornecedor == "PF" & (fornecedor.Rg == null || fornecedor.DataNascimento == null))
                throw new Exception("RG e Data de Nascimento Obrigatório");
            if (empresa.UF == "PR" && fornecedor.TipoFornecedor == "PF")
            {
                DateTime now =  DateTime.Now ;
                int Idade = (now.Year - fornecedor.DataNascimento.Year);
                if (Idade < 18)
                    throw new Exception("Para UF = Paraná , pessoa física somente permitido cadastrar fornecedore Maior de Idade");
            }

            if (fornecedor.TipoFornecedor == "PJ")
            {
                //fornecedor.DataNascimento = null;
                fornecedor.Rg = null;
            }

        }

        public void Inserir(Fornecedor fornecedor, string criadoPor)
        {
            ValidarFornecedor(fornecedor);

            fornecedor.DataCriacao = DateTime.Now;
            fornecedor.CriadoPor = criadoPor;

            repositorioFornecedor.Incluir(fornecedor);
        }

        public Fornecedor ObterPorId(long id)
        {
            return repositorioFornecedor.ObterPorId(id);
        }

        public IEnumerable<Fornecedor> ObterFornecedores()
        {
            return repositorioFornecedor.ObterTodos();
        }

        public void Remover(Fornecedor fornecedor)
        {
            ValidarFornecedor(fornecedor);
            repositorioFornecedor.Excluir(fornecedor.Id);
        }


    }
}
