﻿using System;
using System.Collections.Generic;
using PV.Dominio;
using PV.Dominio.Entidades;
using PV.Dominio.Repositorios;
using PV.Dominio.Servicos;

namespace PV.Aplicacao
{
    public class ServicoEmpresa : IServicoEmpresa
    {
        private readonly IRepositorioEmpresa repositorioEmpresa;


        public ServicoEmpresa(IRepositorioEmpresa repositorioEmpresa)
        {
            this.repositorioEmpresa = repositorioEmpresa ?? throw new ArgumentNullException(nameof(repositorioEmpresa));
        }
        public void Atualizar(Empresa empresa, string alteradoPor)
        {
            ValidarEmpresa(empresa);

            empresa.DataAlteracao = DateTime.Now;
            empresa.AlteradoPor = alteradoPor;

            repositorioEmpresa.Alterar(empresa);
        }

        private void ValidarEmpresa(Empresa empresa)
        {
            if (empresa == null)
                throw new NullReferenceException(nameof(empresa));
            if (empresa.Nome == null)
                throw new Exception("Nome inválido");
            if (empresa.CNPJ == null)
                throw new Exception("CNPJ inválido");
            if (empresa.UF == null)
                throw new Exception("UF inválido");
            string UF = "RO AC AM RR PA AP TO MA PI CE RN PB PE AL SE BA MG ES RJ SP PR SC RS MS MT GO DF";
            bool ufValida = UF.Contains(empresa.UF);
            if (!ufValida)
                throw new Exception("UF inválido");
        }

        public void Inserir(Empresa empresa, string criadoPor)
        {
            ValidarEmpresa(empresa);


            empresa.DataCriacao = DateTime.Now;
            empresa.CriadoPor = criadoPor;

            repositorioEmpresa.Incluir(empresa);
        }

        public Empresa ObterPorId(long id)
        {
            return repositorioEmpresa.ObterPorId(id);
        }

        public IEnumerable<Empresa> ObterEmpresas()
        {
            return repositorioEmpresa.ObterTodos();
        }

        public void Remover(Empresa empresa)
        {
            ValidarEmpresa(empresa);
            repositorioEmpresa.Excluir(empresa.Id);
        }


    }
}
