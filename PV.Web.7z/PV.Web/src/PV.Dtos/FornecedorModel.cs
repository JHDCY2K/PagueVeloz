﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace PV.Dtos
{
    public class FornecedorModel
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        [Display(Name = "Cod. Empresa")]
        public long idEmpresa { get; set; }
        [Display(Name = "CNPJ/ CPF")]
        public string CNPJCPF { get; set; }
        public string Telefone { get; set; }
        [Display(Name = "Tipo Fornecedor")]
        public string TipoFornecedor { get; set; }
        public string Rg { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        [DataType(DataType.Date)]
        [Display(Name = "Data Nascimento")]
        public DateTime DataNascimento { get; set; }
    }
}
