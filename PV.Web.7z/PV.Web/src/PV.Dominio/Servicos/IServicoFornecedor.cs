﻿using System.Collections.Generic;
using PV.Dominio.Entidades;

namespace PV.Dominio
{
    public interface IServicoFornecedor
    {
        Fornecedor ObterPorId(long id);
        IEnumerable<Fornecedor> ObterFornecedores();
        void Atualizar(Fornecedor fornecedor, string alteradoPor);
        void Remover(Fornecedor fornecedor);
        void Inserir(Fornecedor fornecedor, string criadoPor);
    }
}