﻿namespace PV.Dominio
{
    public interface IServicoAutenticacao
    {
        bool Autenticar(string login, string senha);
    }
}
