﻿using System.Collections.Generic;
using PV.Dominio.Entidades;

namespace PV.Dominio
{
    public interface IServicoEmpresa
    {
        Empresa ObterPorId(long id);
        IEnumerable<Empresa> ObterEmpresas();
        void Atualizar(Empresa empresa, string alteradoPor);
        void Remover(Empresa empresa);
        void Inserir(Empresa empresa, string criadoPor);
    }
}