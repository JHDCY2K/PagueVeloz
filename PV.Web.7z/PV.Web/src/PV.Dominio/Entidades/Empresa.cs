﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PV.Dominio.Entidades
{
    public class Empresa : Entidade
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public string UF { get; set; }
        public string CNPJ { get; set; }

    }
}