﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PV.Dominio.Entidades
{
    public class Fornecedor : Entidade
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public long idEmpresa { get; set; }
        public string CNPJCPF { get; set; }
        public string Telefone { get; set; }
        public string TipoFornecedor { get; set; }
        public string Rg { get; set; }
        public DateTime DataNascimento { get; set; }

    }
}