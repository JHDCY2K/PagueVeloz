﻿using System.Linq;
using PV.Dominio.Entidades;

namespace PV.Dominio.Repositorios
{
    public interface IRepositorioFornecedor: IRepositorio<Fornecedor>
    {
        Fornecedor ObterPorNome(string nome);
    }
}