﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PV.Dominio.Entidades;

namespace PV.Dominio.Repositorios
{
    public interface IUnitOfWork
    {
        void SaveChanges();
    }
}