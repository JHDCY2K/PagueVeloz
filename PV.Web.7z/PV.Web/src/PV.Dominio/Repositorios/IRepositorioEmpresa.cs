﻿using System.Linq;
using PV.Dominio.Entidades;

namespace PV.Dominio.Repositorios
{
    public interface IRepositorioEmpresa: IRepositorio<Empresa>
    {
        Empresa ObterPorNome(string nome);
    }
}