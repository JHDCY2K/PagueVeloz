﻿using System.Linq;
using PV.Dominio.Entidades;

namespace PV.Dominio.Repositorios
{
    public interface IRepositorioUsuario: IRepositorio<Usuario>
    {
        Usuario ObterPorLogin(string login);
    }
}