﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using PV.Aplicacao;
using PV.Dados;
using PV.Dados.Repositorios;
using PV.Dominio;
using PV.Dominio.Repositorios;
using PV.Dominio.Servicos;

namespace PV.IoC
{
    public static class RegistrarDependencias
    {
        public static void Registrar(IServiceCollection servicos, IConfiguration configuracao)
        {
            #region ExemploWeb-metadado
            
			
            servicos.AddScoped<IUnitOfWork, UnitOfWork>();
            servicos.AddScoped<ContextoExemploPV>(contexto => new ContextoExemploPV(configuracao.GetConnectionString("DefaultConnection")));

            servicos.AddScoped<IServicoUsuario, ServicoUsuario>();
            servicos.AddScoped<IRepositorioUsuario, RepositorioUsuario>();

            servicos.AddScoped<IRepositorioEmpresa, RepositorioEmpresa>();
            servicos.AddScoped<IServicoEmpresa, ServicoEmpresa>();

            servicos.AddScoped<IRepositorioFornecedor, RepositorioFornecedor>();
            servicos.AddScoped<IServicoFornecedor, ServicoFornecedor>();

            servicos.AddScoped<IServicoAutenticacao, ServicoAutenticacao>();
            servicos.AddScoped<IServicoCriptografia, ServicoCriptografia>();

            servicos.AddDbContext<ContextoExemploPV>(options =>
                                                       options.UseSqlServer(configuracao.GetConnectionString("DefaultConnection")));
            #endregion
        }
    }
}
